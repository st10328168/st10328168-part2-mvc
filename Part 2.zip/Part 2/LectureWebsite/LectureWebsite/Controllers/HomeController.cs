using LectureWebsite.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace LectureWebsite.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly ClaimsDbContext _context;
        private int id;

        public HomeController(ILogger<HomeController> logger, ClaimsDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Claims()
        {
            var claims = _context.Claims.ToList();
            return View(claims);
        }
        public IActionResult CreateEditClaims(int? Id)
        {
            if(Id == null)
            {
                //editing-> load a claim by id 
                var claimInDb = _context.Claims.FirstOrDefault(claim => claim.Id == id);
                return View(claimInDb);
            }
            
            return View();
        }

        public IActionResult DeleteClaim(int id)
        {
            var claimInDb = _context.Claims.FirstOrDefault(claim=> claim.Id == id);
            _context.Claims.Remove(claimInDb);
            _context.SaveChanges();
return RedirectToAction("Claims");
        }
        public IActionResult CreateEditClaimsForm(claimsClass model)
        {
            if(model.Id == 0)
            {
                //create 
                _context.Claims.Add(model);

            }else
            {
                // editing
                _context.Claims.Update(model);
            }
           

            _context.SaveChanges();
            return RedirectToAction("Claims");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
