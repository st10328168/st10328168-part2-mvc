﻿using Microsoft.EntityFrameworkCore;

namespace LectureWebsite.Models
{
    public class ClaimsDbContext : DbContext
    {
       public DbSet<claimsClass> Claims { get; set; }

        public ClaimsDbContext(DbContextOptions<ClaimsDbContext>options)
            : base(options)
        {
            
        }
    }
}
